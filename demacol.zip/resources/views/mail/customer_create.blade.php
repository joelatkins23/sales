<h1>Congratulation {{$name}}!</h1>
<h3>Hope that our service will satisfy you</h3>
<p>Thank you</p>